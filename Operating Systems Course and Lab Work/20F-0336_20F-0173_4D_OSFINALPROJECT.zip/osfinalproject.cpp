#include <iostream>
#include <curl/curl.h>
#include <fstream>
#include<string>
#include<pthread.h>
using namespace std;
 string s;
void code(const char* url);
void fetch_https1(string file);
void *threadfunction(void *arg) {
cout<<s<<endl;
const char* ccx = s.c_str();
code(ccx);
fetch_https1("code.txt");
cout<<"--------------------------------------------------------"<<endl;
return 0;
}

void fetchhttpsbymutithreading(string file)
{


//thread is created
    ifstream in(file);
    int numberofthreads = 0;
    //string s;
    while (!in.eof())
    {
        getline(in, s);
        if (in.eof())
            break;
        numberofthreads++;
    }
    in.close();
    
    pthread_t a_thread[numberofthreads]; //thread declaration
    
    ifstream in2(file);
    for (int i = 0; i < numberofthreads; ++i)
    {
        getline(in2, s);
        if (in2.eof())
            break; 
    pthread_create(&a_thread[i], NULL,threadfunction, NULL);
    }
    for (int i=0;i<numberofthreads;i++)
{

pthread_join(a_thread[i], NULL);
}
    in2.close();
}









void fetch_https(string file)
{
    bool check = true;
    if (file != "code.txt")
    {
        ofstream out("websitehttps.txt");
        out.close();
        check = false;
    }
    cout << "New Site Crawling....." << endl;
    ifstream in(file);
    char ch;
    string https = "";
    while (!in.eof())
    {
        in >> ch;
        if (!in.eof())
        {
            https = "";
            if (ch == '"')
            {
                in >> ch;
                if (ch == 'h')
                {
                    https += ch;
                    in >> ch;
                    if (ch == 't')
                    {
                        https += ch;
                        in >> ch;
                        if (ch == 't')
                        {
                            https += ch;
                            in >> ch;
                            if (ch == 'p')
                            {
                                https += ch;
                                in >> ch;
                                if (ch == 's')
                                {
                                    https += ch;
                                    while (ch != '"' && !in.eof())
                                    {
                                        in >> ch;
                                        if (ch == '"')
                                            break;
                                        https += ch;
                                    }
                                    if (check==true)
                                    {
                                        //cout << https << endl;
                                        ofstream out("websitehttps.txt",ios::app);
                                        out << https << endl;
                                    }
                                    else 
                                        cout << "nothing" << endl;

                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
void fetch_https1(string file)
{
    bool check = true;
    if (file != "code.txt")
    {
        ofstream out("downloaded.txt");
        out.close();
        check = false;
    }
    cout << "New Site Crawling....." << endl;
    ifstream in(file);
    char ch;
    string https = "";
    while (!in.eof())
    {
        in >> ch;
        if (!in.eof())
        {
            https = "";
            if (ch == '"')
            {
                in >> ch;
                if (ch == 'h')
                {
                    https += ch;
                    in >> ch;
                    if (ch == 't')
                    {
                        https += ch;
                        in >> ch;
                        if (ch == 't')
                        {
                            https += ch;
                            in >> ch;
                            if (ch == 'p')
                            {
                                https += ch;
                                in >> ch;
                                if (ch == 's')
                                {
                                    https += ch;
                                    while (ch != '"' && !in.eof())
                                    {
                                        in >> ch;
                                        if (ch == '"')
                                            break;
                                        https += ch;
                                    }
                                    if (check==true)
                                    {
                                        //cout << https << endl;
                                        ofstream out("downloaded.txt",ios::app);
                                        out << https << endl;
                                    }
                                    else 
                                        cout << "nothing" << endl;

                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
void code(const char* url)
{
    CURL *easyhandle = curl_easy_init();
    curl_easy_setopt(easyhandle, CURLOPT_URL, url);
    FILE *file = fopen("code.txt", "w");
    curl_easy_setopt(easyhandle, CURLOPT_WRITEDATA, file);
    curl_easy_perform(easyhandle);
    curl_easy_cleanup(easyhandle);
}
int main()
{
    const char* url="https://www.google.com/";
    code(url);
    fetch_https("code.txt");
    fetchhttpsbymutithreading("websitehttps.txt");
    return 0;
}
