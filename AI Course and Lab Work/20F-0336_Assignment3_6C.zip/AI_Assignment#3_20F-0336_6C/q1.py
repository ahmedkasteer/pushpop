import random
import copy


class NQueens:
    def _init_(self,queensNo):
        self.N = queensNo
        self.board = []
        self.board2 = []
        self.bestCost = 0
        self.bestSol = []  # row number of each queen
        for row in range(self.N):
            temp = []
            for col in range(self.N):
                temp.append(" 0 ")
            self.board.append(temp)
            self.board2.append(temp)

    def displayBoard(self):
        print("Best sol is:", self.bestSol)
        for c in range(self.N):
            r = self.bestSol[c]
            self.board2[r][c] = " 1 "
        for row in range(self.N):
            for col in range(self.N):
                print(self.board2[row][col], end="")
            print()

    def initialSol(self):
        # randomly generated solution
        print("in initialSol")
        for col in range(self.N):
            index = random.randint(0, self.N - 1)
            self.bestSol.append(index)
            self.board[index][col] = " 1 "
            self.board2[index][col] = " 1 "
        self.bestCost = self.calculateCostfunc(self.bestSol)

    def calculateCostfunc(self, solution):
        attack = 0
        print("in cost func")
        for a in range(self.N):
            b = self.bestSol[a]
            self.board2[b][a] = " 1 "

        for rows in range(self.N):
            for r1 in range(self.N):  # row checking for forward movement
                for c1 in range(r1, self.N - 1):
                        if self.board2[rows][r1] == " 1 " and self.board2[rows][c1 + 1] == " 1 ":
                            attack += 2

        for rows in range(self.N):  # column checking for forward movement
            for c2 in range(self.N):
                for r2 in range(r1, self.N - 1):
                        if self.board2[rows][c2] == " 1 " and self.board2[rows + 1][c2] == " 1 ":
                            attack += 2

        for rows in range(self.N - 1):  #  diagonal checking for forward movement
            for r3 in range(self.N - 1):
                for c3 in range(r3, self.N):
                    if self.board2[rows][r3] == " 1 " and self.board2[rows + 1][r3 + 1] == " 1 ":
                        attack += 2

        print("cost is:", attack)

    def simulatedAnnealing(self):
        # to Minimize number
        print("in  Simulated annealing")
        temperature = 500
        rate = 0.1
        newCost = currentCost = self.bestCost  # initially best is current
        newSol = currentSol = copy.deepcopy(self.bestSol)
        while temperature > 0:
            col = random.randint(0, self.N)
            row = random.randint(0, self.N)
            while row == newSol[col]:
                row = random.randint(0, self.N)
            newSol[col] = row
            newCost = self.calculateCostfunc(newSol)
            if newCost == 0:  # number of attacks are none
                self.bestCost = newCost
                self.bestSol = copy.deepcopy(newSol)
                break
            if newCost < currentCost:  # better solution
                self.bestSol = copy.deepcopy(newSol)
                self.bestCost = newCost
                currentSol = copy.deepcopy(newSol)
                currentCost = newCost
            elif (2.71828182 ** (currentCost - newCost) / temperature) > 0:  # probability calculating bad move
                currentSol = copy.deepcopy(newSol)
                currentCost = newCost
        temperature = temperature - rate
        print("Optimum cost is,",self.bestCost," & solution is:")
        self.displayBoard()

n = int(input('\n\tEnter number of queens between 5 to 10 : >> '))
iterations = int(input("Enter number of iterations: "))
obj = NQueens(n)
obj.initialSol()
obj.displayBoard()