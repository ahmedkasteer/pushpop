import copy
board = {
    1: '', 2: '', 3: '',
    4: '', 5: '', 6: '',
    7: '', 8: '', 9: ''}

def printBoard(board):
    print(board[1] + '|' + board[2] + '|' + board[3])
    print('-+-+-')
    print(board[4] + '|' + board[5] + '|' + board[6])
    print('-+-+-')
    print(board[7] + '|' + board[8] + '|' + board[9])
    print('\n')

def spaceVacant(position):
    if (board[position] == ''):
        return True
    else:
        return False
def insertOnBoard(letter, position):
    if (spaceVacant(position)):
        board[position] = letter
        printBoard(board)
        if (checkWithDraw()):
            print('Game Draw! ')
        elif (checkWin()):
            print('WON GAME! ')

def checkWithDraw():
    for key in board.keys():
        if (board[key]==''):
            return False
    return True

def checkWin():
    if (board[1] == board[2] and board[1] == board[3] and board[1] != ''):
        return True
    elif (board[4] == board[5] and board[4] == board[6] and board[4] != ''):
        return True
    elif (board[7] == board[8] and board[7] == board[9] and board[7] != ''):
        return True
    elif (board[1] == board[5] and board[1] == board[9] and board[1] != ''):
        return True
    elif (board[3] == board[5] and board[3] == board[7] and board[3] != ''):
        return True
    elif (board[1] == board[4] and board[1] == board[7] and board[1] != ''):
        return True
    elif (board[2] == board[5] and board[2] == board[8] and board[2] != ''):
        return True
    elif (board[3] == board[6] and board[3] == board[9] and board[3] != ''):
        return True
    else:
        return False


def isMovesLeft(board):
   for i in board.keys():
       if board[i] == '':
           return True
   return False

def minmax(board, depth, isMax):
    if isMovesLeft(board) == False:
        return 0

    # If this maximizer's move
    if isMax:
        best = -1000

        # Traverse all cells
        for i in board.keys():
            if board[i] == '' :
                # Make the move
                board[i] = 'X'

                # Call minimax recursively and choose
                # the maximum value
                best = max(best, minmax(board,
                                        depth + 1,
                                        not isMax))

                # Undo the move
                board[i] = ''
        return best

        # If this minimizer's move
    else:
        best = 1000

        # Traverse all cells
        for i in board.keys():
            if board[i] == '' :
                # Make the move
                board[i] = 'O'

                # Call minimax recursively and choose
                # the minimum value
                best = min(best, minmax(board, depth + 1, not isMax))

                # Undo the move
                board[i] = ''
        return best

    # This will return the best possible move for the player
def botMove():
    bestVal = -1000
    bestMove = -1

    # Traverse all cells, evaluate minimax function for
    # all empty cells. And return the cell with optimal
    # value.

    for i in board.keys():

        # Check if cell is empty
        if (board[i] == ''):

            # Make the move
            board[i] = 'X'

            # compute evaluation function for this
            # move.
            moveVal = minmax(board, 0, False)

            # Undo the move
            board[i] = ''

            # If the value of the current move is
            # more than the best value, then update
            # best/
            if (moveVal > bestVal):
                bestMove = (i)
                bestVal = moveVal

    insertOnBoard('X',bestMove)
# Press the green button in the gutter to run the script.

def playerMove():
    ind = int(input("please enter index:"))
    insertOnBoard('O',ind)
if __name__ == '__main__':
    printBoard(board)
    while not checkWin() or not checkWithDraw():
        botMove()
        playerMove()
        printBoard(board)
