import random



class Graph:
    graph = {}
    domain = {}
    finalColor = {}
    def _init_(self):
        self.graph = {}
        self.domain = {}
        self.finalColor = {}
    def addEdge(self, u, v):
        if u not in self.graph:
            self.graph[u] = []
        if v not in self.graph:
            self.graph[v] = []
        self.graph[u].append(v)

    def printGraph(self):
        for key in self.graph.keys():
            self.domain[key] = ["Red", "Green", "Blue"]
            print(key, self.graph[key])


    def cspColorMapping(self):
        for node in self.graph:
            if node in self.domain and self.domain[node]:
                index = random.randint(0, len(self.domain[node])-1)
                color = self.domain[node][index]
                self.finalColor[node] = color
                for neighbour in self.graph[node]:
                    if neighbour in self.domain and color in self.domain[neighbour]:
                        self.domain[neighbour].remove(color)





    def displaySolution(self):
        print("")
        print("The colors for nodes are as follows: ")
        print("")
        for node in self.graph:
            if node in self.finalColor:
                print(node, "--->", self.finalColor[node])
            else:
                print(node, "---> Blank" )

g = Graph()

g.addEdge("a","b")
g.addEdge("a","c")
g.addEdge("a","d")

g.addEdge("c","a")
g.addEdge("c","d")
g.addEdge("c","f")



g.addEdge("b","a")
g.addEdge("b","d")
g.addEdge("b","e")

g.addEdge("d","a")
g.addEdge("d","b")
g.addEdge("d","c")
g.addEdge("d","e")
g.addEdge("d","f")
g.addEdge("d","g")

g.addEdge("e","b")
g.addEdge("e","d")
g.addEdge("e","g")

g.addEdge("f","c")
g.addEdge("f","d")

g.addEdge("g","e")
g.addEdge("g","d")


g.printGraph()
g.cspColorMapping()
g.displaySolution()
